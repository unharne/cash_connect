# CashConnect
ATM Simulator🏧

## Developers

[@unharne](https://github.com/unharne)

[@Daytona1315](https://github.com/Daytona1315)

[![Typing SVG](https://readme-typing-svg.herokuapp.com?color=%2336BCF&lines=by+Star+Genius)](https://git.io/typing-svg)